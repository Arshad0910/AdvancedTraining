import java.util.*;
public class TestBook {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		CreateandShowBooks object = new CreateandShowBooks();
		System.out.println("Enter the title of the book");
		String title = scanner.nextLine();
		System.out.println("Enter the description of the book");
		String description = scanner.nextLine();
		System.out.println("Enter the price of the book");
		int price = scanner.nextInt();
		object.createBook(title, description, price);
		object.showBooks();
		
		scanner.close();
	}
}

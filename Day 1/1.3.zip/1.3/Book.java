class Book {
	String title;
	String description;
	int price;
	
	Book() {
		title = "";
		description = "";
		price = 0;
	}
	
	void setTitle(String title) {
		this.title = title;
	}
	
	void setDescription(String description) {
		this.description = description;
	}
	
	void setPrice(int price) {
		this.price = price;
	}
	
	String getTitle() {
		return title;
	}
	
	String getDescription() {
		return description;
	}
	
	int getPrice() {
		return price;
	}
}
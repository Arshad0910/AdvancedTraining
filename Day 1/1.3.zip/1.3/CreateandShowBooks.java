
public class CreateandShowBooks extends Book {
	
	void createBook(String title, String description, int price) {
		setTitle(title);
		setDescription(description);
		setPrice(price);
	}
	
	void showBooks() {
		System.out.println(getTitle());
		System.out.println(getDescription());
		System.out.println(getPrice());
	}
}



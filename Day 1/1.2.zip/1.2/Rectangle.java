package One;

class Rectangle {
	int length;
	int breadth;
	int area;
	//Default Length and Breadth if no value is provided by the user.
	Rectangle() {
		length = 0;
		breadth = 0;
		area = 0;
	}
	
	//Length and Breadth provided by the user.
	/* RectangleInfo(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	} */
	
	//Accessor for Length
	int getLength() {
		return length;
	}
	
	//Accessor for Breadth of the rectangle 
	int getBreadth() {
		return breadth;
	}
	
	//Mutator for Length of the rectangle
	void setLength(int l) {
		length = l;
	}
	
	//Mutator for Breadth of the rectangle
	void setBreadth(int b) {
		breadth = b;
	}
	//Calculate the area of the rectangle
	void calculateArea(int l, int b) {
		area = length * breadth;
	}
	
	//return the area of the rectangle
	int getArea() {
		return area;
	}
}
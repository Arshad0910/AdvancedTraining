
class Operations {
	int length(String string) {
		return string.length();
	}
	
String Palindrome(String string) {
		String temp = string;
		char[] character = string.toCharArray();
		String reversed = "";
		for(int i = character.length - 1; i >= 0; i--) {
			reversed += character[i];
		}
		if(temp.equals(reversed))
			return "Palindrome";
		else
			return "Not a Palindrome";
	}

	String UpperCase(String string) {
		string = string.toUpperCase();
		return string;
	}
	
}
public class LengthUpperCasePalindromeString {
	public static void main(String[] args) {
		String string = args[0];
		
		Operations object = new Operations();
		
		System.out.println(object.length(string));
		System.out.println(object.Palindrome(string));
		System.out.println(object.UpperCase(string));
		
	}
}

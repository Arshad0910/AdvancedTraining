import java.util.*;
public class Array {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the length of the array");
		int length = scanner.nextInt();
		int[] array = new int[length];
		for(int i = 0; i < length; i++) {
			System.out.println("Enter the " + i + "th element");
			array[i] = scanner.nextInt();
		}
		
		//Calculate the sum of array from 0th index to 14th and store it in 15th index
		int sum = 0;
		for(int i = 0; i < 14; i++) {
			sum += array[i];
		}
		array[15] = sum;
		System.out.println("The sum is " + sum);
		
		//Find the average of all numbers in the array and store it at 16th index
		int sumOfArray = 0;
		for(int i = 0; i < length; i++) {
			sumOfArray = sumOfArray + array[i];
		}
		double average = sumOfArray / length;
		array[16] = (int) average;
		System.out.println("The average is " + average);
		
		//Find the smallest element in the array and store it at 17th index
		int smallest = 0;
		for(int i = 0; i < length; i++) {
			int a = 0;
			int b = 1;
			if(array[a] < array[b])
				smallest = array[a];
			a++;
			b++;
		}
		System.out.println("The smallest element in the array is " + smallest);
		
		//Print Resultant Array
		System.out.print("Elements of the array are: ");
		for(int i = 0; i < length; i++) {
			System.out.print(array[i] + " ");
		}
		scanner.close();
	}
}

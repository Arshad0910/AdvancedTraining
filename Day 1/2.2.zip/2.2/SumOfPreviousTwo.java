
public class SumOfPreviousTwo {
	public static void main(String[] args) {
		int number1 = Integer.parseInt(args[0]);
		int number2 = Integer.parseInt(args[1]);
		
		System.out.println("Number1: " + number1);
		System.out.println("Number2: " + number2);
		
		System.out.print("Sum of the Previous Two Series: ");
		System.out.print(number1 + " ");
		System.out.print(number2 + " ");
		int sum = 0;
		for(int i = 0; i < 13; i++) {
			sum = number1 + number2;
			int temp = number1;
			number1 = number2;
			number2 = sum;
			System.out.print(sum + " ");
		}
	}
}

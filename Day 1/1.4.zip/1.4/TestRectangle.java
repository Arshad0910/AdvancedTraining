import java.util.*;

public class TestRectangle {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		Rectangle object1 = new Rectangle();
		System.out.println("Enter the length of the rectangle");
		double length1 = scanner.nextInt();
		System.out.println("Enter the breadth of the rectangle");
		double breadth1 = scanner.nextInt();
		object1.setLength(length1);
		object1.setBreadth(breadth1);
		
		System.out.println("The length of the rectangle1 is " + object1.length);
		System.out.println("The breadth of the rectangle1 is " + object1.breadth);
		object1.calculateArea(length1, breadth1);
		object1.calculatePerimeter(length1, breadth1);
		System.out.println("The area of the rectangle1 is " + object1.getArea());
		System.out.println("The perimeter of the rectangle1 is " + object1.getPerimeter());
		///////////////////////////////////////////////////////////////////////
		Rectangle object2 = new Rectangle();
		System.out.println("Enter the length of the rectangle");
		double length2 = scanner.nextInt();
		System.out.println("Enter the breadth of the rectangle");
		double breadth2 = scanner.nextInt();
		object2.setLength(length2);
		object2.setBreadth(breadth2);
		
		System.out.println("The length of the rectangle2 is " + object2.length);
		System.out.println("The breadth of the rectangle2 is " + object2.breadth);
		object2.calculateArea(length2, breadth2);
		object2.calculatePerimeter(length2, breadth2);
		System.out.println("The area of the rectangle2 is " + object2.getArea());
		System.out.println("The perimeter of the rectangle2 is " + object2.getPerimeter());
		////////////////////////////////////////////////////////////////////////
		Rectangle object3 = new Rectangle();
		System.out.println("Enter the length of the rectangle");
		double length3 = scanner.nextInt();
		System.out.println("Enter the breadth of the rectangle");
		double breadth3 = scanner.nextInt();
		object3.setLength(length3);
		object3.setBreadth(breadth3);
		
		System.out.println("The length of the rectangle3 is " + object3.length);
		System.out.println("The breadth of the rectangle3 is " + object3.breadth);
		object3.calculateArea(length3, breadth3);
		object3.calculatePerimeter(length3, breadth3);
		System.out.println("The area of the rectangle3 is " + object3.getArea());
		System.out.println("The perimeter of the rectangle3 is " + object3.getPerimeter());
		/////////////////////////////////////////////////////////////////////////
		Rectangle object4 = new Rectangle();
		System.out.println("Enter the length of the rectangle");
		double length4 = scanner.nextInt();
		System.out.println("Enter the breadth of the rectangle");
		double breadth4 = scanner.nextInt();
		object4.setLength(length4);
		object4.setBreadth(breadth4);
		
		System.out.println("The length of the rectangle4 is " + object4.length);
		System.out.println("The breadth of the rectangle4 is " + object4.breadth);
		object4.calculateArea(length4, breadth4);
		object4.calculatePerimeter(length4, breadth4);
		System.out.println("The area of the rectangle4 is " + object4.getArea());
		System.out.println("The perimeter of the rectangle is " + object4.getPerimeter());
		/////////////////////////////////////////////////////////////////////////
		Rectangle object5 = new Rectangle();
		System.out.println("Enter the length of the rectangle");
		double length5 = scanner.nextInt();
		System.out.println("Enter the breadth of the rectangle");
		double breadth5 = scanner.nextInt();
		object5.setLength(length5);
		object5.setBreadth(breadth5);
		
		System.out.println("The length of the rectangle5 is " + object5.length);
		System.out.println("The breadth of the rectangle5 is " + object5.breadth);
		object5.calculateArea(length5, breadth5);
		object5.calculatePerimeter(length5, breadth5);
		System.out.println("The area of the rectangle5 is " + object5.getArea());
		System.out.println("The perimeter of the rectangle5 is " + object5.getPerimeter());
		scanner.close();
	}
}
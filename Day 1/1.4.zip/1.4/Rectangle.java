class Rectangle {
	double length;
	double breadth;
	double area;
	double perimeter;
	//Default Length and Breadth if no value is provided by the user.
	Rectangle() {
		length = 0.0;
		breadth = 0.0;
		area = 0.0;
		perimeter = 0.0;
	}
	
	//Length and Breadth provided by the user.
	/* RectangleInfo(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	} */
	
	//Accessor for Length
	double getLength() {
		return length;
	}
	
	//Accessor for Breadth of the rectangle 
	double getBreadth() {
		return breadth;
	}
	
	//Mutator for Length of the rectangle
	void setLength(int l) {
		if(l > 0.0 && l < 20.0)
			length = l;
	}
	
	//Mutator for Breadth of the rectangle
	void setBreadth(int b) {
		if(b > 0.0 && b < 20.0)
			breadth = b;
	}
	
	//Calculate the area of the rectangle
	void calculateArea(int l, int b) {
		area = length * breadth;
	}
	
	//Calculate the perimeter of the rectangle
	void calculatePerimeter(int l, int b) {
		perimeter = 2 * (l + b);
	}
	
	//return the area of the rectangle
	float getArea() {
		return area;
	}
	
	//return the perimeter of the rectangle
	float getPerimeter() {
		return perimeter;
	}
}